# import logging

# def time(operation):
#     raise NotImplementedError

# def log(level, information):
#     logging.basicConfig(level=logging.INFO)
#     if level == logging.INFO:
#         logging.info(information)
#     elif level == logging.ERROR:
#         logging.error(information)
#     elif level == logging.WARNING:
#         logging.warning(information)
#     else:
#         raise TypeError