# def generate(udfunction, mode = "forward"):
#     """[summary]

#     Args:
#         udfunction ([type]): [description]
#         mode (str, optional): [description]. Defaults to "forward".
#     """
#     raise NotImplementedError