# def evaluate(f):
#     raise NotImplementedError

# def parse(udfunction):
#     raise NotImplementedError