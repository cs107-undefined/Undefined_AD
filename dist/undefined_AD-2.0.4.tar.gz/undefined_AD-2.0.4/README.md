# cs107-FinalProject

[![Build Status](https://app.travis-ci.com/cs107-undefined/cs107-FinalProject.svg?branch=milestone2)](https://app.travis-ci.com/cs107-undefined/cs107-FinalProject)

[![codecov](https://codecov.io/gh/cs107-undefined/cs107-FinalProject/branch/milestone2/graph/badge.svg?token=MWEZONI94C)](https://codecov.io/gh/cs107-undefined/cs107-FinalProject)

[**DOCUMENTATION**](https://cs107-undefined.readthedocs.io/en/latest/)


**Group Number:**

Group 1

**Group Members:**

_Xinran Tang xinran_tang@g.harvard.edu_

_Renhao Luo renhao_luo@hms.harvard.edu_

_Chelse Swoopes cswoopes@g.harvard.edu_

_Shijia Zhang shijiazhang@hms.harvard.edu_
